Transfer Learning Dataset In Pervasive Computing

Copyright by Vincent W. Zheng (http://www.cse.ust.hk/~vincentz).
Any question, please send email to vincentz_AT_cse.ust.hk.
October 19th, 2008.

---------------------------------------------------------------------------------------------------

[Paper]: "Transferring Localization Models Over Time". In AAAI-08.
	 Vincent W. Zheng, Evan W. Xiang, Qiang Yang and Dou Shen. 

---------------------------------------------------------------------------------------------------

[Data]: WiFiTimeData10.mat

---------------------------------------------------------------------------------------------------

[Data Oerview]: 

WiFiTime data is to study the WiFi signal variation over time.

(1) The data is collected at in an academic building of Hong Kong University of Science and Technology. 
    The environment is equipped with 802.11g wireless network. The area is 64m x 50m, including five hallways. 
    It��s discretized into a space of 118 grids, each measuring 1.5m x 1.5m. 

(2) Totally, 5 different time periods data are collected: 08:26, 11:21, 13:54, 16:21, 19:10.

    For each time period, we collect the data as follows: 
    At each grid, 60 examples are collected. To validate the Hidden Markov Model, 
    we also designed a number of user traces, whose observations are randomly picked from the examples from each grid.

---------------------------------------------------------------------------------------------------

[Detailed Description]:

Load WiFiTimeData10.mat in Matlab, and we will get:

(1) 'd0826' denotes the data collected at 08:26, with rows as examples, 
    first 10 columns as features (signal strengths from 10 access points*), 
    the 11th column as the example's corresponding grid index. 
    Note that the feature values are processed by adding Gaussian noise N(0,1) for computation convenience.

    Similarly, we also have 'd1121'/'d1354'/'d1621'/'d1910'.

    * Totally, we detect 67 access points; in this work, we manually select 10 most useful access points for localization.
      We will release the data with full 67 access points later.

(2) 'trn0826' denotes the (training) traces that we designed for our experiments.
    
    These traces are generated similar to (X. Chai and Q. Yang. "Reducing the calibration effort 
    for location estimation using unlabeled samples". In PerCom05). We planed several different 
    walk trips that navigate over the hallways and consists of a sequence of location points; 
    a sample at each of those locations was then randomly selected from Tr and concatenated to form a trace.

    Each cell is a trace, with rows as features, columns as trace length (or, # of grids travelled).

    Similarly, we also have 'trn1121', 'trn1354', 'trn1621', 'trn1910'.

    The corresponding labels are recorded in 'trn1121label', 'trn1354label', 'trn1621label', 'trn1910label'.

(3) 'tst1121' denotes the (testing) traces that we designed for our experiments.

    The generation procedure is the same as (2).

    Each cell is a trace, with rows as features, columns as trace length (or, # of grids travelled).

    Similarly, we also have 'tst1354', 'tst1621', 'tst1910'. (08:26 used as time 0, its data for training only in our paper)

    The corresponding labels are recorded in tst1354label', 'tst1621label', 'tst1910label'.


(4) 'hallway' denotes which grids are covered at each hallway.

(5) 'location' denotes the 2-D physical coordinates for all the grids.

(6) 'nref' denotes the number of reference points (RPs) at each hallway.
    Row i denotes that, if we select (i*10) percents of the grids as RPs, 
    how many grids at each hallway need to be selected. Here, we try to 
    select RPs evenly at each hallway, which is a manual way to do RP placement.

(7) 'nex' denotes the number of examples collected at each grid for each time period. 
    Similarly, 'ntrn' denotes the number of examples out of all examples are used as training data; 
    and 'ntst' denotes as the number of examples as testing data.


